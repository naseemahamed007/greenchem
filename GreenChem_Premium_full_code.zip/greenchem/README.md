# GreenChem

Interactive Green Chemistry exhibition website built with React + Vite.

## Run locally

1. Install Node.js (LTS).
2. Open this folder in a terminal.
3. Run:

```bash
npm install
npm run dev
```

4. Open the local Vite URL shown in the terminal.

## Build for deployment

```bash
npm run build
```

The production files are generated in `dist/`.

## Included

- Responsive GreenChem landing page
- 12 Green Chemistry principles
- Interactive Traditional vs Green process lab
- Animated Green Score
- Waste calculator
- Atom economy demo
- Quick score tool
- 5-question quiz
- Exhibition Mode for presenting to judges
- Mobile responsive layout
- Framer Motion animations
- Lucide icons

The numerical process values are explicitly illustrative for an educational demonstration and should not be presented as measured industrial data.
