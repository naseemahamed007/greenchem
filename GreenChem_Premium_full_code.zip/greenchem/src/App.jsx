import React, { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowRight, Atom, BarChart3, Beaker, CheckCircle2, ChevronDown,
  CircleHelp, FlaskConical, Leaf, Menu, Recycle, RotateCcw, ShieldCheck,
  Sparkles, Trophy, X, Zap
} from "lucide-react";

const principles = [
  ["01","Prevent Waste","Preventing waste is better than treating or cleaning it up later.","Recycle"],
  ["02","Atom Economy","Design reactions so that as much of the starting material as possible becomes the desired product.","Atom"],
  ["03","Less Hazardous Synthesis","Use methods that generate substances with little or no toxicity.","ShieldCheck"],
  ["04","Safer Chemicals","Design products that work effectively while reducing harmful effects.","Leaf"],
  ["05","Safer Solvents","Avoid auxiliary substances where possible, or choose safer alternatives.","FlaskConical"],
  ["06","Energy Efficiency","Minimize energy requirements and prefer conditions near ambient temperature and pressure.","Zap"],
  ["07","Renewable Feedstocks","Prefer renewable raw materials when technically and economically practical.","Leaf"],
  ["08","Reduce Derivatives","Avoid unnecessary temporary modifications such as protecting groups.","RotateCcw"],
  ["09","Catalysis","Use catalytic reagents rather than stoichiometric reagents whenever possible.","Sparkles"],
  ["10","Design for Degradation","Design products to break down into harmless substances after use.","Recycle"],
  ["11","Real-time Analysis","Monitor processes in real time to prevent hazardous substances from forming.","BarChart3"],
  ["12","Accident Prevention","Choose substances and conditions that reduce the potential for accidents.","ShieldCheck"]
];

const quiz = [
  { q:"What is the main goal of green chemistry?", a:["Create more waste","Prevent pollution at its source","Use more hazardous chemicals","Increase energy consumption"], correct:1 },
  { q:"Which approach is preferred?", a:["Treat waste after making it","Prevent waste from being created","Ignore by-products","Use hazardous solvents"], correct:1 },
  { q:"What does atom economy focus on?", a:["How much starting material becomes the desired product","The color of a reaction","How fast a reaction looks","The size of a laboratory"], correct:0 },
  { q:"Which is a green chemistry principle?", a:["Maximum waste","Safer solvents","More toxic reagents","Unnecessary derivatives"], correct:1 },
  { q:"Why are catalysts useful?", a:["They can improve efficiency and reduce resource use","They always increase waste","They make every reaction dangerous","They replace every reactant"], correct:0 }
];

function Icon({name, size=22}) {
  const map = {Recycle, Atom, ShieldCheck, Leaf, FlaskConical, Zap, RotateCcw, Sparkles, BarChart3};
  const C = map[name] || Leaf;
  return <C size={size}/>;
}

function Score({score}) {
  const radius = 48, circumference = 2 * Math.PI * radius;
  const offset = circumference - (score/100)*circumference;
  return (
    <div className="score-wrap">
      <svg className="score-ring" viewBox="0 0 120 120">
        <circle className="ring-bg" cx="60" cy="60" r={radius}/>
        <motion.circle
          className="ring-progress" cx="60" cy="60" r={radius}
          strokeDasharray={circumference}
          initial={{strokeDashoffset:circumference}}
          animate={{strokeDashoffset:offset}}
          transition={{duration:1.2,ease:"easeOut"}}
        />
      </svg>
      <div className="score-number">{score}<span>/100</span></div>
    </div>
  );
}

function Navbar({page,setPage}) {
  const [open,setOpen] = useState(false);
  const links = [["home","Home"],["learn","Learn"],["lab","Green Lab"],["tools","Tools"],["quiz","Quiz"]];
  return (
    <header className="nav">
      <button className="brand" onClick={()=>setPage("home")}><span className="brand-mark"><Leaf size={20}/></span>GreenChem</button>
      <nav className={open ? "nav-links open" : "nav-links"}>
        {links.map(([id,label])=><button key={id} className={page===id?"active":""} onClick={()=>{setPage(id);setOpen(false)}}>{label}</button>)}
      </nav>
      <button className="nav-cta" onClick={()=>setPage("lab")}>Start Lab <ArrowRight size={16}/></button>
      <button className="menu-btn" onClick={()=>setOpen(!open)} aria-label="Menu">{open?<X/>:<Menu/>}</button>
    </header>
  );
}

function Home({setPage}) {
  return <main>
    <section className="hero">
      <div className="orb orb-a"/><div className="orb orb-b"/>
      <div className="hero-copy">
        <div className="eyebrow"><span className="pulse"/>11th–12th Chemistry • Interactive Model</div>
        <h1>Chemistry for a<br/><em>cleaner future.</em></h1>
        <p>Explore how smarter chemical design can reduce waste, energy use and hazards — through an interactive Green Chemistry laboratory.</p>
        <div className="hero-actions">
          <button className="primary" onClick={()=>setPage("lab")}>Explore Green Lab <ArrowRight/></button>
          <button className="secondary" onClick={()=>setPage("learn")}>Learn Green Chemistry</button>
        </div>
        <div className="mini-stats"><span><b>12</b> principles</span><span><b>5</b> interactive tools</span><span><b>1</b> sustainability goal</span></div>
      </div>
      <div className="molecule-scene">
        <div className="molecule-core"><Atom size={58}/></div>
        {[0,1,2,3,4,5].map(i=><motion.div key={i} className="molecule-dot" style={{"--i":i}} animate={{rotate:360}} transition={{duration:10+i*2,repeat:Infinity,ease:"linear"}}><span/></motion.div>)}
        <div className="leaf-float l1">🌿</div><div className="leaf-float l2">♻️</div><div className="leaf-float l3">⚗️</div>
      </div>
    </section>

    <section className="section">
      <div className="section-head"><div><span className="kicker">THE IDEA</span><h2>Make chemistry <span>smarter.</span></h2></div><p>Green chemistry is not just about cleaning up pollution. It is about designing chemistry so less pollution is created in the first place.</p></div>
      <div className="feature-grid">
        <Feature icon={<Recycle/>} title="Prevent waste" text="Design processes that create less waste from the beginning."/>
        <Feature icon={<Zap/>} title="Save energy" text="Prefer efficient reactions and conditions that require less energy."/>
        <Feature icon={<ShieldCheck/>} title="Reduce hazards" text="Choose safer substances and processes whenever possible."/>
      </div>
    </section>

    <section className="dark-band">
      <div><span className="kicker light">TRY IT</span><h2>Turn a chemical process into a sustainability score.</h2><p>Compare a conventional process with a greener alternative and see the difference.</p></div>
      <button className="light-btn" onClick={()=>setPage("lab")}>Open Green Lab <ArrowRight/></button>
    </section>
  </main>;
}

function Feature({icon,title,text}) {
  return <motion.div className="feature-card" whileHover={{y:-7}} transition={{type:"spring",stiffness:300}}>
    <div className="icon-box">{icon}</div><h3>{title}</h3><p>{text}</p><span className="card-arrow">↗</span>
  </motion.div>
}

function Learn() {
  return <main className="page">
    <PageTitle kicker="LEARN" title={<>The 12 principles of <span>Green Chemistry.</span></>} text="Use the cards below as your interactive chemistry reference."/>
    <div className="principles">
      {principles.map(([n,title,text,icon],i)=><motion.article key={n} className="principle" initial={{opacity:0,y:25}} whileInView={{opacity:1,y:0}} viewport={{once:true,amount:.2}} transition={{delay:(i%4)*.04}}>
        <div className="principle-top"><span>{n}</span><div className="small-icon"><Icon name={icon}/></div></div>
        <h3>{title}</h3><p>{text}</p>
      </motion.article>)}
    </div>
  </main>
}

function PageTitle({kicker,title,text}) {
  return <div className="page-title"><span className="kicker">{kicker}</span><h1>{title}</h1><p>{text}</p></div>
}

function ProcessFlow({green}) {
  const items = green ? ["Renewable / safer input","Catalyst + efficient reaction","Desired product","Minimal waste"] : ["Raw materials","Chemical reaction","Desired product","Waste + hazards"];
  return <div className={green?"process green-process":"process"}>
    {items.map((x,i)=><React.Fragment key={x}>
      <motion.div className="process-node" initial={{opacity:0,scale:.8}} animate={{opacity:1,scale:1}} transition={{delay:i*.15}}><span>{i===0?"●":i===1?"⚗":i===2?"◆":"♻"}</span><b>{x}</b></motion.div>
      {i<items.length-1 && <div className="process-line"><motion.i animate={{x:[0,35,0]}} transition={{duration:1.5,repeat:Infinity}}/></div>}
    </React.Fragment>)}
  </div>
}

function GreenLab() {
  const [mode,setMode] = useState("green");
  const [showDetails,setShowDetails] = useState(false);
  const data = mode==="green" ? {waste:15,energy:35,hazard:20,renewable:true,score:91} : {waste:70,energy:80,hazard:75,renewable:false,score:32};
  return <main className="page">
    <PageTitle kicker="GREEN LAB" title={<>See the difference. <span>Interact with it.</span></>} text="Switch between a conventional and greener process. The values are illustrative for educational demonstration."/>
    <div className="lab-switch"><button className={mode==="traditional"?"selected red":""} onClick={()=>setMode("traditional")}>Traditional process</button><button className={mode==="green"?"selected green":""} onClick={()=>setMode("green")}>Green process</button></div>
    <AnimatePresence mode="wait">
      <motion.div key={mode} className="lab-card" initial={{opacity:0,x:mode==="green"?30:-30}} animate={{opacity:1,x:0}} exit={{opacity:0,x:mode==="green"?-30:30}}>
        <div className="lab-heading"><div><span className={mode==="green"?"tag green-tag":"tag red-tag"}>{mode==="green"?"GREEN ROUTE":"CONVENTIONAL ROUTE"}</span><h2>{mode==="green"?"Designed for efficiency":"Conventional approach"}</h2></div><Score score={data.score}/></div>
        <ProcessFlow green={mode==="green"}/>
        <div className="metric-grid">
          <Metric label="Waste" value={data.waste+"%"} good={data.waste<30}/>
          <Metric label="Energy demand" value={data.energy+"%"} good={data.energy<50}/>
          <Metric label="Hazard level" value={data.hazard+"%"} good={data.hazard<30}/>
          <Metric label="Renewable input" value={data.renewable?"YES":"NO"} good={data.renewable}/>
        </div>
        <button className="text-btn" onClick={()=>setShowDetails(!showDetails)}>{showDetails?"Hide":"Show"} explanation <ChevronDown size={16}/></button>
        <AnimatePresence>{showDetails&&<motion.div className="explanation" initial={{height:0,opacity:0}} animate={{height:"auto",opacity:1}} exit={{height:0,opacity:0}}>
          {mode==="green" ? "The green route demonstrates the principles of waste prevention, energy efficiency, safer chemistry and renewable feedstocks." : "The conventional route is intentionally shown with higher illustrative waste, energy demand and hazard indicators so the comparison is easy to understand."}
        </motion.div>}</AnimatePresence>
      </motion.div>
    </AnimatePresence>
  </main>
}

function Metric({label,value,good}) {
  return <div className="metric"><span>{label}</span><b className={good?"good":"bad"}>{value}</b><div className="bar"><i style={{width:value.includes("%")?value:"35%"}}/></div></div>
}

function Tools() {
  const [raw,setRaw]=useState(100), [product,setProduct]=useState(85), [atom,setAtom]=useState(85);
  const waste=Math.max(0,Number(raw)-Number(product));
  const wastePct=Number(raw)>0 ? (waste/Number(raw))*100 : 0;
  const atomEco=Math.max(0,Math.min(100,Number(atom)));
  return <main className="page">
    <PageTitle kicker="TOOLS" title={<>Measure the <span>green difference.</span></>} text="Simple calculators for a live exhibition demonstration."/>
    <div className="tool-grid">
      <ToolCard title="♻ Waste Calculator" subtitle="Estimate material lost as waste.">
        <label>Raw material (g)<input type="number" value={raw} onChange={e=>setRaw(e.target.value)}/></label>
        <label>Product obtained (g)<input type="number" value={product} onChange={e=>setProduct(e.target.value)}/></label>
        <div className="result"><b>{waste.toFixed(1)} g</b><span>waste • {wastePct.toFixed(1)}%</span></div>
      </ToolCard>
      <ToolCard title="⚛ Atom Economy Demo" subtitle="Explore how efficiently reactants become desired product.">
        <input className="range" type="range" min="0" max="100" value={atom} onChange={e=>setAtom(e.target.value)}/>
        <div className="range-labels"><span>0%</span><strong>{atomEco}%</strong><span>100%</span></div>
        <div className="atom-visual"><span style={{width:`${atomEco}%`}}/></div>
        <p className="tiny">Higher atom economy means a larger fraction of reactant atoms are incorporated into the desired product.</p>
      </ToolCard>
      <ToolCard title="🌱 Quick Green Score" subtitle="Adjust the factors to see how the score behaves.">
        <Score score={Math.round((100-wastePct*.35)*.5 + (100-atomEco)*.1 + atomEco*.4)}/>
        <p className="tiny center">A demonstration score — not a formal industrial assessment.</p>
      </ToolCard>
    </div>
  </main>
}

function ToolCard({title,subtitle,children}) {
  return <section className="tool-card"><h2>{title}</h2><p>{subtitle}</p>{children}</section>
}

function Quiz() {
  const [index,setIndex]=useState(0), [selected,setSelected]=useState(null), [score,setScore]=useState(0), [done,setDone]=useState(false);
  const q=quiz[index];
  function choose(i){if(selected!==null)return;setSelected(i);if(i===q.correct)setScore(s=>s+1)}
  function next(){if(index===quiz.length-1)setDone(true);else{setIndex(i=>i+1);setSelected(null)}}
  function restart(){setIndex(0);setSelected(null);setScore(0);setDone(false)}
  return <main className="page quiz-page">
    <PageTitle kicker="QUIZ" title={<>How green is your <span>chemistry knowledge?</span></>} text="Five quick questions for visitors and judges."/>
    {!done ? <div className="quiz-card">
      <div className="quiz-progress"><span>Question {index+1} of {quiz.length}</span><div><i style={{width:`${((index+1)/quiz.length)*100}%`}}/></div></div>
      <h2>{q.q}</h2>
      <div className="answers">{q.a.map((a,i)=><button key={a} onClick={()=>choose(i)} className={selected===i?(i===q.correct?"correct":"wrong"):(selected!==null&&i===q.correct?"correct":"")}>{String.fromCharCode(65+i)}. {a}{selected!==null&&i===q.correct?<CheckCircle2/>:null}</button>)}</div>
      {selected!==null&&<div className={selected===q.correct?"feedback correct-bg":"feedback wrong-bg"}>{selected===q.correct?"Correct!":"Not quite."} {q.a[q.correct]}</div>}
      {selected!==null&&<button className="primary next-btn" onClick={next}>{index===quiz.length-1?"See result":"Next question"} <ArrowRight/></button>}
    </div> :
    <div className="result-card"><Trophy size={50}/><span className="kicker">RESULT</span><h2>{score} / {quiz.length}</h2><p>{score===5?"Excellent — Green Chemistry expert!":score>=3?"Strong foundation. Keep exploring!":"Good start — revisit the principles and try again."}</p><button className="primary" onClick={restart}><RotateCcw/> Try again</button></div>}
  </main>
}

function Exhibition({setPage}) {
  const slides=[
    ["01","The challenge","Chemical processes can create waste, consume energy and involve hazardous substances."],
    ["02","The idea","Green chemistry designs chemistry to prevent or reduce those problems at the source."],
    ["03","The demonstration","GreenChem compares two illustrative process routes using waste, energy, hazard and renewable-input indicators."],
    ["04","The result","A simple Green Score makes the trade-offs easy to see and discuss."],
    ["05","The takeaway","Better chemistry can mean better products, safer processes and a smaller environmental footprint."]
  ];
  const [i,setI]=useState(0);
  const s=slides[i];
  return <main className="presentation"><div className="presentation-top"><button className="brand" onClick={()=>setPage("home")}><span className="brand-mark"><Leaf size={20}/></span>GreenChem</button><span>Exhibition Mode</span><button onClick={()=>setPage("home")} className="close-pres"><X/></button></div>
    <div className="slide"><span className="slide-no">{s[0]}</span><span className="kicker light">GREEN CHEMISTRY</span><h1>{s[1]}</h1><p>{s[2]}</p><div className="slide-icon"><Leaf size={70}/></div></div>
    <div className="slide-controls"><button disabled={i===0} onClick={()=>setI(i-1)}>← Previous</button><span>{i+1} / {slides.length}</span><button disabled={i===slides.length-1} onClick={()=>setI(i+1)}>Next →</button></div>
  </main>
}

function App(){
  const [page,setPage]=useState("home");
  return <div className="app"><Navbar page={page} setPage={setPage}/>
    {page==="home"&&<Home setPage={setPage}/>}
    {page==="learn"&&<Learn/>}
    {page==="lab"&&<GreenLab/>}
    {page==="tools"&&<Tools/>}
    {page==="quiz"&&<Quiz/>}
    {page==="exhibition"&&<Exhibition setPage={setPage}/>}
    {page!=="exhibition"&&<footer><div><span className="brand-mark"><Leaf size={17}/></span> GreenChem</div><div className="developer-credit">Designed &amp; developed by <strong>Naseem Ahamed</strong></div><button onClick={()=>setPage("exhibition")}>🎤 Exhibition Mode</button></footer>}
  </div>
}

export default App;